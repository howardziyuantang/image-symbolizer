import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static final String RESET = "\u001B[0m";
    public static final String BLACK_BG = "\u001B[40m";
    public static final String[] COLOR_CODES = {"\u001B[30m","\u001B[31m","\u001B[32m","\u001B[33m","\u001B[34m","\u001B[35m","\u001B[36m","\u001B[37m"};
    public static final Color[] colors = {Color.black,Color.red,Color.green,Color.yellow,Color.blue,Color.magenta,Color.cyan,Color.white};

    public static void main(String[] args) throws IOException {

        BufferedImage img = ImageIO.read(new File("Source Images/sn.jpg"));
        int newWidth = 80;
        img = resizeImage(img, newWidth, (int)((double)img.getHeight()*newWidth/img.getWidth()));
        char[] symbols = {' ', '-', ':', '!', '?', '&', '$'};
//        char[] symbols = " `.-':_,^=;><+!rc*/z?sLTv)J7(|Fi{C}fI31tlu[neoZ5Yxjya]2ESwqkP6h9d4VpOGbUAKXHm8RD#$Bg0MNWQ%&@".toCharArray();
        FileWriter out = new FileWriter("Symbolized Image");
        out.flush();
        for(int i = 0; i < img.getHeight(); i++) {
            for(int j = 0; j < img.getWidth(); j++) {
                int rgb = img.getRGB(j, i);
                Color current = (rgb>>24==0x00) ? Color.black : new Color(rgb);
                for(int k = 0; k < 3; k++)
                    out.write(symbols[/*symbols.length-1-*/(int)((symbols.length-1)*((current.getRed()+current.getGreen()+current.getBlue())/3d/255))]);/*System.out.print(BLACK_BG+bestCode(current)+symbols[(int)((symbols.length-1)*((current.getRed()+current.getGreen()+current.getBlue())/3d/255))]+RESET);*/
            }
            out.write("\n");/*System.out.print("\n");*/
        }
        out.close();

    }

    /*private static String bestCode(Color targetColor) {
        int minDiff = 256*3;
        String code = "\u001B[37m";
        for(int i = 0; i < colors.length; i++) {
            int diff = Math.abs(targetColor.getRed()-colors[i].getRed())+Math.abs(targetColor.getBlue()-colors[i].getBlue())+Math.abs(targetColor.getGreen()-colors[i].getGreen());
            if(diff<minDiff) {
                minDiff = diff;
                code = COLOR_CODES[i];
            }
        }
        return code;
    }*/

    private static BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics2D = resizedImage.createGraphics();
        graphics2D.drawImage(originalImage, 0, 0, targetWidth, targetHeight, null);
        graphics2D.dispose();
        return resizedImage;
    }

}
